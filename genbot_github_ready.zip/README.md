# Gen Bot

## Setup
1. Install with `pip install -r requirements.txt`
2. Replace `YOUR_BOT_TOKEN` in `app.py`
3. Run using `python app.py`

Supports:
- +gen
- +access
- +stock
- Persistent access tracking
